local BAG = BankAlone
BAG.Branding.Layout = {
    frameWidth = 360,
    frameHeight = 420,
    padding = 12,
    headerHeight = 28,
    stepSpacing = 6,
    buttonHeight = 22,
}

