local BAG = BankAlone
BAG.Data.Items = {
  [6948] = { name = "Hearthstone", purpose = "Return to your chosen home point." },
  [117] = { name = "Tough Jerky", purpose = "Early food for quick recovery." },
  [159] = { name = "Refreshing Spring Water", purpose = "Basic drink for mana classes." },
  [2901] = { name = "Mining Pick", purpose = "Required for mining nodes." },
  [7005] = { name = "Skinning Knife", purpose = "Required for skinning beasts." },
  [6218] = { name = "Runed Copper Rod", purpose = "Enchanting tool for low levels." },
  [33470] = { name = "Frostweave Cloth", purpose = "Tailoring and bandage material." },
  [2459] = { name = "Swiftness Potion", purpose = "Short burst of speed for travel." },
  [22575] = { name = "Mote of Life", purpose = "Primal Life conversion for crafts." },
  [22577] = { name = "Mote of Shadow", purpose = "Primal Shadow conversion for crafts." },
}
