local BAG = BankAlone
BAG.Data.Items = {
    { id = 2589, name = "Linen Cloth", purpose = "Starter cloth used for tailoring and bandages." },
    { id = 2770, name = "Copper Ore", purpose = "Early mining material for smelting and crafting." },
    { id = 2447, name = "Peacebloom", purpose = "Low-level herb for alchemy basics." },
    { id = 2318, name = "Light Leather", purpose = "Common leather for early leatherworking." },
    { id = 17031, name = "Runecloth", purpose = "High-level cloth for bags and first aid." },
    { id = 14047, name = "Runecloth Bolt", purpose = "Processed runecloth for tailoring plans." },
    { id = 21877, name = "Netherweave Cloth", purpose = "Outland cloth for tailoring and bandages." },
    { id = 23424, name = "Fel Iron Ore", purpose = "Outland ore for blacksmithing and engineering." },
    { id = 22577, name = "Mote of Shadow", purpose = "Elemental reagent for alchemy and enchanting." },
    { id = 6948, name = "Hearthstone", purpose = "Returns you to your home inn." },
}

