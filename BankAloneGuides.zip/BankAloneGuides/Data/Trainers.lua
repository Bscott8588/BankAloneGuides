local BAG = BankAlone
BAG.Data.Trainers = {
  { id = 2329, name = "Michelle Belle", zone = "Elwynn Forest", x = 42.7, y = 65.6, profession = "Cooking", note = "Goldshire cook trainer." },
  { id = 1710, name = "Keldric Boucher", zone = "Elwynn Forest", x = 43.7, y = 65.8, profession = "First Aid", note = "Field medic basics." },
  { id = 1681, name = "Brock Stoneseeker", zone = "Loch Modan", x = 63.0, y = 48.7, profession = "Mining", note = "Teaches the pick basics." },
  { id = 1684, name = "Khara Deepwater", zone = "Dun Morogh", x = 59.5, y = 35.5, profession = "Blacksmithing", note = "Forge apprentice." },
  { id = 2132, name = "Carolai Anise", zone = "Tirisfal Glades", x = 61.5, y = 52.1, profession = "Alchemy", note = "Undercity alchemy trainer." },
  { id = 3184, name = "Miao'zan", zone = "Orgrimmar", x = 54.2, y = 38.8, profession = "Cooking", note = "Orgrimmar cook." },
  { id = 8126, name = "Nixx Sprocketspring", zone = "Stranglethorn Vale", x = 28.3, y = 77.5, profession = "Engineering", note = "Booty Bay gadget trainer." },
  { id = 4552, name = "Eunice Burch", zone = "Tirisfal Glades", x = 65.9, y = 59.4, profession = "Tailoring", note = "Undead tailoring." },
  { id = 2836, name = "Brikk Keencraft", zone = "Stranglethorn Vale", x = 28.1, y = 77.5, profession = "Engineering", note = "Advanced circuits coach." },
  { id = 18991, name = "Aresella", zone = "Shattrath City", x = 45.1, y = 24.3, profession = "Enchanting", note = "Outland enchanting trainer." },
}
