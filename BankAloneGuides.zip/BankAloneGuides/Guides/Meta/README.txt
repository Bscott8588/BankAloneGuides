Placeholder for meta or overview guides.
