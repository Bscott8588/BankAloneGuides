Placeholder for class-specific guides.
