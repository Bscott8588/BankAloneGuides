Placeholder for custom icons.
