Placeholder for custom textures.
